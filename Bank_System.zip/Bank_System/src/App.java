import banking.BankingSystemMain;

public final class App 
{
    private App() {
    }

    
    public static void main(String[] args) 
    {
        BankingSystemMain.main(args);
    }
}
