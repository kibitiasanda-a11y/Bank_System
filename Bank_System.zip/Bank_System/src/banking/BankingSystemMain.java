package banking;

import java.util.Scanner;

public final class BankingSystemMain 
{
    private static final java.nio.file.Path TRANSACTION_LOG =
            java.nio.file.Paths.get("transactions.txt");
    private static final java.time.format.DateTimeFormatter TRANSACTION_TIME =
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final Scanner scanner = new Scanner(System.in);
    // Polymorphism: one BankAccount collection holds both account subclasses.
    private final BankAccount[] accounts = 
    {
        new SavingsAccount("9010", "Lefa Moopisa", 5_000.00),
        new CurrentAccount("9020", "Refuoe Lechesa", 3_000.00)
    };

    public static void main(String[] args) 
    {
        BankingSystemMain bankingSystem = new BankingSystemMain();
        bankingSystem.run();
    }

    private void run() 
    {
        System.out.println("Welcome to the Console Banking System.");
        boolean running = true;
        while (running) {
            // Exception handling
            try {
                displayMenu();
                String choice = scanner.nextLine().trim();
                switch (choice) {
                    case "1":
                        displayAllAccounts();
                        break;
                    case "2":
                        performDeposit();
                        break;
                    case "3":
                        performWithdrawal();
                        break;
                    case "4":
                        performTransfer();
                        break;
                    case "5":
                        calculateInterest();
                        break;
                    case "6":
                        requestLoan();
                        break;
                    case "7":
                        displayAccountDetails();
                        break;
                    case "8":
                        running = false;
                        System.out.println("Thank you for using the Console Banking System.");
                        break;
                    default:
                        System.out.println("Invalid menu choice. Enter a number from 1 to 8.");
                        recordTransaction("N/A", "MENU_CHOICE", "N/A", "N/A",
                                "REJECTED: invalid menu choice '" + choice + "'.");
                }
            } catch (java.util.NoSuchElementException exception) {
                running = false;
                System.out.println("\nInput ended. Exiting the banking system.");
            }
        }
    }

    private void displayMenu() 
    {
        System.out.println();
        System.out.println("1. Display all accounts");
        System.out.println("2. Deposit money");
        System.out.println("3. Withdraw money");
        System.out.println("4. Transfer money");
        System.out.println("5. Calculate interest");
        System.out.println("6. Request bank loan");
        System.out.println("7. Display account details");
        System.out.println("8. Exit");
        System.out.print("Choose an option: ");
    }

    private void displayAllAccounts() 
    {
        for (int i = 0; i < accounts.length; i++) {
            accounts[i].displayDetails();
        }
    }

    private void performDeposit() 
    {
        BankAccount account = promptForAccount("deposit into", "DEPOSIT");
        double amount = promptForAmount(account, "DEPOSIT");
        executeTransaction(account, "DEPOSIT", amount, () -> account.deposit(amount), "Deposit successful.");
    }

    private void performWithdrawal() 
    {
        BankAccount account = promptForAccount("withdraw from", "WITHDRAWAL");
        double amount = promptForAmount(account, "WITHDRAWAL");
        executeTransaction(account, "WITHDRAWAL", amount, () -> account.withdraw(amount),
                "Withdrawal successful.");
    }

    private void performTransfer() 
    {
        BankAccount source = promptForAccount("transfer from", "TRANSFER_SENT");
        BankAccount destination = promptForAccount("transfer to", "TRANSFER_DESTINATION");
        double amount = promptForAmount(source, "TRANSFER_SENT");
        boolean transferred = executeTransaction(source, "TRANSFER_SENT", amount,
                () -> source.transferTo(destination, amount),
                "Transfer successful.", "SUCCESS: transferred to account " + destination.getAccountNumber());
        if (transferred) {
            recordTransaction(destination, "TRANSFER_RECEIVED", amount,
                    "SUCCESS: received from account " + source.getAccountNumber());
        }
    }

    private void calculateInterest() 
    {
        BankAccount account = promptForAccount("calculate interest for", "INTEREST");
        try {
            double interest = account.calculateInterest();
            recordTransaction(account, "INTEREST", interest, "SUCCESS: interest credited.");
            System.out.println("Interest credited: M" + interest);
        } catch (IllegalArgumentException | IllegalStateException exception) {
            recordTransaction(account, "INTEREST", 0, "REJECTED: " + exception.getMessage());
            System.out.println("Interest calculation failed: " + exception.getMessage());
        }
    }

    private void requestLoan() 
    {
        BankAccount account = promptForAccount("request a loan for", "LOAN_REQUEST");
        double amount = promptForAmount(account, "LOAN_REQUEST");
        if (!(account instanceof Loanable)) {
            System.out.println("This account is not eligible for loans.");
            recordTransaction(account, "LOAN_REQUEST", amount, "REJECTED: account is not eligible for loans.");
            return;
        }
        executeTransaction(account, "LOAN_REQUEST", amount,
                () -> ((Loanable) account).requestLoan(amount),
                "Loan approved and credited to the account.");
    }

    private boolean executeTransaction(BankAccount account, String type, double amount,
            Runnable transaction, String successMessage) 
            {
        return executeTransaction(account, type, amount, transaction, successMessage, "SUCCESS");
    }

    private boolean executeTransaction(BankAccount account, String type, double amount,
            Runnable transaction, String successMessage, String successResult) 
            {
        // Exception handling
        try {
            transaction.run();
            recordTransaction(account, type, amount, successResult);
            System.out.println(successMessage);
            return true;
        } catch (IllegalArgumentException | IllegalStateException exception) {
            recordTransaction(account, type, amount, "REJECTED: " + exception.getMessage());
            System.out.println("Transaction rejected: " + exception.getMessage());
            return false;
        }
    }

    private void recordTransaction(BankAccount account, String type, double amount, String result) {
        recordTransaction(account.getAccountNumber(), type, formatAmount(amount),
                formatAmount(account.getBalance()), result);
    }

    private void recordTransaction(String accountNumber, String type, String amount, String balance, String result) {
        String entry = java.time.LocalDateTime.now().format(TRANSACTION_TIME)
                + " | Account: " + accountNumber
                + " | Type: " + type
                + " | Amount: " + amount
                + " | Balance: " + balance
                + " | " + result
                + System.lineSeparator();
        try {
            java.nio.file.Files.write(TRANSACTION_LOG,
                    entry.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        } catch (java.io.IOException exception) {
            System.err.println("Could not write transaction to " + TRANSACTION_LOG + ": "
                    + exception.getMessage());
        }
    }

    private String formatAmount(double amount) 
    {
        return String.format(java.util.Locale.ROOT, "M%.2f", amount);
    }

    private void displayAccountDetails() 
    {
        promptForAccount("display", "ACCOUNT_DISPLAY").displayDetails();
    }

    private BankAccount promptForAccount(String purpose, String transactionType) 
    {
        while (true) {
            System.out.println("Enter the account number to " + purpose + ":");
            displayAccountNumbers();
            System.out.print("Account number: ");
            String accountNumber = scanner.nextLine().trim();
            for (int i = 0; i < accounts.length; i++) {
                if (accounts[i].getAccountNumber().equals(accountNumber)) {
                    return accounts[i];
                }
            }
            System.out.println("Account number was not found. Please try again.");
            recordTransaction(accountNumber, transactionType, "N/A", "N/A",
                    "REJECTED: account number was not found.");
        }
    }

    private void displayAccountNumbers() 
    {
        for (int i = 0; i < accounts.length; i++) {
            System.out.println(accounts[i].getAccountNumber() + " - " + accounts[i].getAccountHolder()
                    + " (" + accounts[i].getAccountType() + ")");
        }
    }

    private double promptForAmount(BankAccount account, String transactionType) 
    {
        while (true) {
            System.out.print("Amount (M): ");
            String input = scanner.nextLine().trim();
            try {
                double amount = Double.parseDouble(input);
                if (Double.isFinite(amount) && amount > 0) {
                    return amount;
                }
            } catch (NumberFormatException exception) {
    // The invalid entry is reported and logged below before prompting again.
            }
            System.out.println("Enter a valid amount greater than zero.");
            recordTransaction(account.getAccountNumber(), transactionType, input,
                    formatAmount(account.getBalance()), "REJECTED: invalid numeric input '" + input + "'.");
        }
    }
}
