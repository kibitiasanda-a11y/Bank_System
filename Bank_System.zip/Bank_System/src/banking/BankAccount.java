package banking;

// Abstract superclass: shared account data and required banking operations.
public abstract class BankAccount 
{
// Encapsulation: account data stays private and changes only through account operations.
    private final String accountNumber;
    private final String accountHolder;
    private double balance;

    protected BankAccount(String accountNumber, String accountHolder, double openingBalance) 
    {
        if (accountNumber == null || accountNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Account number cannot be blank.");
        }
        if (accountHolder == null || accountHolder.trim().isEmpty()) {
            throw new IllegalArgumentException("Account holder cannot be blank.");
        }
        if (!Double.isFinite(openingBalance) || openingBalance < 0) {
            throw new IllegalArgumentException("Opening balance cannot be negative.");
        }
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = openingBalance;
    }

    public final String getAccountNumber() 
    {
        return accountNumber;
    }

    public final String getAccountHolder() 
    {
        return accountHolder;
    }

    public final double getBalance() 
    {
        return balance;
    }

    public abstract void deposit(double amount);

    public abstract void withdraw(double amount);

    public abstract double calculateInterest();

    protected abstract double getMinimumBalance();

    protected abstract double getOverdraftLimit();

    protected final void validatePositiveAmount(double amount) 
    {
        if (!Double.isFinite(amount) || amount <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
    }

    protected final double projectedBalance(double change) 
    
    {
        double updatedBalance = balance + change;
        if (!Double.isFinite(updatedBalance) || Math.abs(updatedBalance) > Long.MAX_VALUE / 100.0) {
            throw new IllegalArgumentException("The resulting balance is outside the supported range.");
        }
        return Math.round(updatedBalance * 100.0) / 100.0;
    }

    protected final void changeBalance(double amount) 
    {
        balance = projectedBalance(amount);
    }

    public final double getAvailableFunds() 
    {
        return balance - getMinimumBalance() + getOverdraftLimit();
    }

    public final void transferTo(BankAccount recipient, double amount) 
    {
        synchronized (BankAccount.class) {
            if (!Double.isFinite(amount) || amount <= 0) {
                throw new IllegalArgumentException("Transfer amount must be greater than zero.");
            }
            if (recipient == null || recipient == this) {
                throw new IllegalArgumentException("Choose a different, valid destination account.");
            }
            if (amount > getAvailableFunds()) {
                throw new IllegalStateException("Insufficient available funds for this transfer.");
            }

            projectedBalance(-amount);
            recipient.projectedBalance(amount);
            changeBalance(-amount);
            recipient.changeBalance(amount);
        }
    }

    public final String getAccountType() 
    {
        return getClass().getSimpleName();
    }

    public final void displayDetails() 
    {
        System.out.println("Account: " + accountNumber
                + " | Holder: " + accountHolder
                + " | Type: " + getAccountType()
                + " | Balance: M" + balance
                + " | Available: M" + getAvailableFunds());
    }

}
