package banking;

// Inheritance and interface implementation: a current account is a bank account and can request loans.
public class CurrentAccount extends BankAccount implements Loanable 
{
    private static final double OVERDRAFT_LIMIT = 2_000.00;
    private static final double LOAN_LIMIT = 20_000.00;

    public CurrentAccount(String accountNumber, String accountHolder, double openingBalance) 
    {
        super(accountNumber, accountHolder, openingBalance);
    }

    @Override
    public void deposit(double amount) 
    {
        validatePositiveAmount(amount);
        changeBalance(amount);
    }

    @Override
    public void withdraw(double amount) 
    {
        validatePositiveAmount(amount);
        if (amount > getAvailableFunds()) 
            {
            throw new IllegalStateException("Insufficient funds; overdraft limit is M2,000.00.");
        }
        changeBalance(-amount);
    }

    // Overriding
    @Override
    public double calculateInterest() 
    {
        return 0.0;
    }

    @Override
    protected double getMinimumBalance() 
    {
        return 0;
    }

    @Override
    protected double getOverdraftLimit() 
    {
        return OVERDRAFT_LIMIT;
    }

    @Override
    public void requestLoan(double amount) 
    {
        if (!Double.isFinite(amount) || amount <= 0) 
            {
            throw new IllegalArgumentException("Loan amount must be greater than zero.");
        }
        if (amount > LOAN_LIMIT) 
            {
            throw new IllegalArgumentException("Current account loan limit is M20,000.00.");
        }
        changeBalance(amount);
    }
}
