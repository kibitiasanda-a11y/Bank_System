package banking;

// Inheritance and interface implementation: a savings account is a bank account and can request loans.
public class SavingsAccount extends BankAccount implements Loanable 
{
    private static final double MINIMUM_BALANCE = 100.00;
    private static final double ANNUAL_INTEREST_RATE = 0.05;
    private static final double LOAN_LIMIT = 100000.00;

    public SavingsAccount(String accountNumber, String accountHolder, double openingBalance) 
    {
        super(accountNumber, accountHolder, openingBalance);
    }

    @Override
    public void deposit(double amount) 
    {
        validatePositiveAmount(amount);
        changeBalance(amount);
    }

    @Override
    public void withdraw(double amount) 
    {
        validatePositiveAmount(amount);
        if (getBalance() - amount < MINIMUM_BALANCE) 
            {
            throw new IllegalStateException("Savings account must retain at least M100.00.");
        }
        changeBalance(-amount);
    }

    // Overriding: savings accounts earn and receive 5% annual interest.
    @Override
    public double calculateInterest() 
    {
        double interest = Math.round(getBalance() * ANNUAL_INTEREST_RATE * 100.0) / 100.0;
        changeBalance(interest);
        return interest;
    }

    // Polymorphic account rules are supplied by each concrete subclass.
    @Override
    protected double getMinimumBalance() 
    {
        return MINIMUM_BALANCE;
    }

    @Override
    protected double getOverdraftLimit() 
    {
        return 0;
    }

    @Override
    public void requestLoan(double amount) 
    {
        if (!Double.isFinite(amount) || amount <= 0) 
            {
            throw new IllegalArgumentException("Loan amount must be greater than zero.");
        }
        if (amount > LOAN_LIMIT) 
            {
            throw new IllegalArgumentException("Savings account loan limit is M100000.00.");
        }
        changeBalance(amount);
    }
}
